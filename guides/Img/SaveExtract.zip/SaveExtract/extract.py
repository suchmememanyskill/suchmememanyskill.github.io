# Made by SuchMemeManySkill

import subprocess
import os

def findintext(txt, find) -> str:
    for x in txt.split("\\r\\n"):
        if find in x:
            return x.split(":")[1].strip()

if __name__ == "__main__":
    directory = os.fsencode("./save")
    for file in os.listdir(directory):
        filename = os.fsdecode(file)

        print(f"Extracting {filename}")
        text = str(subprocess.check_output(["hactoolnet.exe", "-k", "prod.keys", "-t", "save" , f"save/{filename}", "--outdir", f"out/{filename}"]))
        portion = findintext(text, "Title ID:").upper()

        if portion != None:
            print(f"{filename} => {portion}")
            if (os.path.exists(f"out/{portion}")):
                dirnumber = 1
                while (os.path.exists(f"out/{portion}_{dirnumber}")):
                    dirnumber += 1
                os.rename(f"out/{filename}", f"out/{portion}_{dirnumber}")
            else:
                os.rename(f"out/{filename}", f"out/{portion}")